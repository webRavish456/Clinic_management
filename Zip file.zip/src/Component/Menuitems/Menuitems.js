const Menuitems = [
    
    {
        icon: '/Sidebar/dashboard.png',
        label: "Dashboard",
        href: "/",
    },
    {
      icon: '/Sidebar/patient.png',
      label: "Patients",
      href: "/patients",
    },
    {
       icon: "/Sidebar/service.png",
       label: "Staff",
       href: "/staff",
      },
    {
      icon: "/sidebar/medical-appointment.png",
      label: "Appointment",
      href: "/appointment",
    },
    {
      icon: "/Sidebar/doctor.png",
      label: "Doctor",
      href: "/doctor",
    },
    {
      icon: "/Sidebar/experiment-results.png",
      label: "Laboratory",
      href: "/laboratory",
    },
    {
      icon: "/Sidebar/accounting.png",
      label: "Finance",
      href: "/finance",
    },

];



export default Menuitems;